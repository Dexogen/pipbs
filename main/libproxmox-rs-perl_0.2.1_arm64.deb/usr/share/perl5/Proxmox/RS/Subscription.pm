package Proxmox::RS::Subscription;
use base 'Proxmox::Lib::Common';
BEGIN { __PACKAGE__->bootstrap(); }
1;

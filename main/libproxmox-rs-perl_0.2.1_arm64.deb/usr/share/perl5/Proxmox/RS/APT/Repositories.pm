package Proxmox::RS::APT::Repositories;
use base 'Proxmox::Lib::Common';
BEGIN { __PACKAGE__->bootstrap(); }
1;

package Proxmox::RS::CalendarEvent;
use base 'Proxmox::Lib::Common';
BEGIN { __PACKAGE__->bootstrap(); }
1;

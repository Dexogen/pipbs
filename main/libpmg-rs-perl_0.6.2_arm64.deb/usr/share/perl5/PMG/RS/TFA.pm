package PMG::RS::TFA;
use base 'Proxmox::Lib::PMG';
BEGIN { __PACKAGE__->bootstrap(); }
1;

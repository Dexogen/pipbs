package PMG::RS::OpenId;
use base 'Proxmox::Lib::PMG';
BEGIN { __PACKAGE__->bootstrap(); }
1;

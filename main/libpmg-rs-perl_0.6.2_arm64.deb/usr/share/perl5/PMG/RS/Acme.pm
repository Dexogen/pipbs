package PMG::RS::Acme;
use base 'Proxmox::Lib::PMG';
BEGIN { __PACKAGE__->bootstrap(); }
1;

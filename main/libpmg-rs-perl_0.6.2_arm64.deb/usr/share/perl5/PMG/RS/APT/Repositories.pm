package PMG::RS::APT::Repositories;
use base 'Proxmox::Lib::PMG';
BEGIN { __PACKAGE__->bootstrap(); }
1;
